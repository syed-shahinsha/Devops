package com.lti.controller;

import java.io.File;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class RegisterController {

	@Autowired
	RegisterDao dao;

	@RequestMapping(path = "/register.lti", method = RequestMethod.POST)
	public String execute(UserDTO userDTO) {
		
		//code for processing the uploaded file
		String path="d:/uploads/";
		String filename=userDTO.getName()+ '-'+userDTO.getProfilePic().getOriginalFilename();
		String finalPath=path+filename;
		try {
			userDTO.getProfilePic().transferTo(new File(finalPath));
			System.out.println("Uploaded");
		}catch(Exception e) {
			e.printStackTrace();
		}
		//now the code to store the data in database
		//instead of the code written below, we can go on
		//with the libraries like BeanUtils or ObjectMapper
		//for automatically copying data from object to another
		User user=new User();
		user.setName(userDTO.getName());
		user.setAge(userDTO.getAge());
		user.setCity(userDTO.getCity());
		user.setEmail(userDTO.getEmail());
		user.setProfilePic(filename);
		dao.addUser(user);
		
		return "hello.jsp";
	}

	@RequestMapping(path="/searchUser.lti", method =RequestMethod.POST)
	public String search(@RequestParam("email") String email,Map<String,Object> model) {
		
		User user=dao.fetchByEmailId(email);
		model.put("user", user);
		return "Search.jsp";
	}
}
