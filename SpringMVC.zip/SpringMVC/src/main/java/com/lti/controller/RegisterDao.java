package com.lti.controller;

import java.util.List;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Component;

@Component("dao")
public class RegisterDao {

	@PersistenceContext
	private EntityManager em;
	
	@Transactional
	public void addUser(User user) {
		em.merge(user);
	}
	
	public User fetchByEmailId(String email){
		return em.find(User.class, email);
	}
	
}
