package com.lti.controller;

import java.util.List;

public interface RegisterDaoInterface {

	public void addUser(User user);
	public List<User> fetchAll();
}
