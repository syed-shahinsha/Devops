package testForModelPackage;

import static org.junit.Assert.*;

import org.junit.Test;

import daoForModel.AlbumDao;
import model.Album;
import model.Songs;

public class AlbumTest {

	@Test
	public void testAddAlbum() {
		Album album=new Album();
		album.setName("One Direction");
		album.setYear(2003);
		album.setCopyright("One Direction");
		AlbumDao dao=new AlbumDao();
		dao.save(album);
	}
	@Test
	public void testAddSong() {
		AlbumDao dao=new AlbumDao();
		Album album=(Album) dao.fetchById(Album.class, 227);
		Songs song=new Songs();
		song.setSinger("Four");
		song.setTitle("Best Song Ever");
		song.setDuration(5.15);
		song.setAlbum(album);
		dao.save(song);
	}
	
}
