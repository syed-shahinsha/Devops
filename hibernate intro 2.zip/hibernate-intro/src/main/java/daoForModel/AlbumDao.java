package daoForModel;

import com.lti.dao.GenericDao;

public class AlbumDao extends GenericDao{

	
}
