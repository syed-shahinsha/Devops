package com.homealoan.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.homealoan.Service.RegistrationService;
import com.homealoan.entity.UserRegistration;


@RestController
@Component
public class UserRegistrationController {
	@Autowired
	RegistrationService regserv;
	
		@RequestMapping(value = "/userRegistration", method = RequestMethod.POST)
		public int addUser(@RequestBody UserRegistration user) {
		UserRegistration userReg=regserv.register(user);
		return userReg.getId();
		 }
	

}
