package com.homealoan.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.homealoan.Dao.UserRegisterDao;
import com.homealoan.entity.UserRegistration;

@Service
public class RegistrationService {

	@Autowired
	UserRegisterDao dao;
	
	public UserRegistration register(UserRegistration user) {
	
		return dao.save(user);
	}

}
