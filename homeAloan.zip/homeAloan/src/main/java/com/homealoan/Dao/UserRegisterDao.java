package com.homealoan.Dao;

import org.springframework.stereotype.Repository;

@Repository
public class UserRegisterDao extends GenericDao {

}
