package com.homealoan.Dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class GenericDao {

	@PersistenceContext
	EntityManager em;
	
	@Transactional
	public <E> E save(E e) {
		return em.merge(e);
	}
}
