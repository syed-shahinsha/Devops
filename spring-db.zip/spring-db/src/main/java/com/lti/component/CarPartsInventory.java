package com.lti.component;
import java.util.List;

public interface CarPartsInventory {

	 public int addNewPart(CarPart carPart);
		 
	 public List<CarPart> getAvailableParts();
	
	
}
