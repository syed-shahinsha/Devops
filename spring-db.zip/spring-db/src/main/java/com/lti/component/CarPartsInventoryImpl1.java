package com.lti.component;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Component;

@Component("carPartsImpl1")
public class CarPartsInventoryImpl1 implements CarPartsInventory {

	 public int addNewPart(CarPart carPart) {
		//Jdbc code here
		 
		 	Connection conn= null;											//manages the connection between the app and 
			PreparedStatement stmt = null;	
			int result = 0;//helps us to execute SQL statements
			
			try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				
				String user = "hr";
				String pass = "hr";
				conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE",user,pass); 	//Calling the url                                                  
				
				String sql = "insert into TBL_CARPARTS values(?,?,?,?)";
				stmt = conn.prepareStatement(sql);
				
				stmt.setInt (1,  carPart.getPartNo());
				stmt.setString (2,  carPart.getPartName());
				stmt.setString(3,  carPart.getCarModel());
				stmt.setInt(4,  carPart.getQuantity());
				result=stmt.executeUpdate();
				return result;
			}
			
			catch(ClassNotFoundException e) {
				System.out.println("JDBC driver not found");
			}
			
			catch(SQLException e) {
				e.printStackTrace();
			}
			finally {
				try {
				conn.close();
				}catch(Exception e){
					e.printStackTrace();
				}
				return result;
			}
	
		}

	 
	 public List<CarPart> getAvailableParts(){
		 return null;
	 }
}
