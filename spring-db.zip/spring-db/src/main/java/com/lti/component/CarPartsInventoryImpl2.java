package com.lti.component;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("carPartsImpl2")
public class CarPartsInventoryImpl2 implements CarPartsInventory {

	@Autowired
	private DataSource dataSource1;

	public int addNewPart(CarPart carPart) {
		// Jdbc code here

		Connection conn = null; // manages the connection between the app and
		PreparedStatement stmt = null; // helps us to execute SQL statements
		int result=0;
		try {
			conn = dataSource1.getConnection(); // Calling the url

			String sql = "insert into TBL_CARPARTS values(?,?,?,?)";
			stmt = conn.prepareStatement(sql);

			stmt.setInt(1, carPart.getPartNo());
			stmt.setString(2, carPart.getPartName());
			stmt.setString(3, carPart.getCarModel());
			stmt.setInt(4, carPart.getQuantity());
			result=stmt.executeUpdate();
			
		}

		catch (SQLException e) {
			e.printStackTrace();
		}

		finally {
			try {
				conn.close();
			} catch (Exception e) {
			}return result;
		}

	}

	public List<CarPart> getAvailableParts() {
		return null;
	}
}
