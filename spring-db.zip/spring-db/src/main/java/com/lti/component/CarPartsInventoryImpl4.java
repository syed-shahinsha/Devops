package com.lti.component;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component("carPartsImpl4")
public class CarPartsInventoryImpl4 implements CarPartsInventory {

	@PersistenceContext
	private EntityManager em;
	@Transactional
	public int addNewPart(CarPart carPart) {
		em.persist(carPart);
		return 1; //given just for rectifying error, Hibernate will anyway add the object as a row in sql
		}

	public List<CarPart> getAvailableParts() {
		/*Query q=em.createQuery("select c from CarPart c");
		List<CarPart> list=q.getResultList();
		return list;
		*/
		//we can also write this as
		return em.createQuery("select c from CarPart c").getResultList();
	}
}
