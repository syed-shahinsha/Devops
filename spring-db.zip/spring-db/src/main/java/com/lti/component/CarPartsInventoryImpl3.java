package com.lti.component;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

@Component("carPartsImpl3")
public class CarPartsInventoryImpl3 implements CarPartsInventory {

	@Autowired
	private DataSource dataSource1;

	public int addNewPart(CarPart carPart) {
		//introducing spring's jdbc template
		JdbcTemplate jt=new JdbcTemplate(dataSource1);
		int result=0;
		result=jt.update(
			"insert into TBL_CARPARTS values(?,?,?,?)",
			carPart.getPartNo(),
			carPart.getPartName(),
			carPart.getCarModel(),
			carPart.getQuantity()
			);
		return result;
		}

		class CarPartRowMapper implements RowMapper<CarPart>{
			public CarPart mapRow(ResultSet rs, int rowNum) throws SQLException {
				CarPart part=new CarPart();
				part.setPartNo(rs.getInt(1));
				part.setPartName(rs.getString(2));
				part.setCarModel(rs.getString(3));
				part.setQuantity(rs.getInt(4));
				return part;
			}
		}

	public List<CarPart> getAvailableParts() {
		JdbcTemplate jt=new JdbcTemplate(dataSource1);
		String sql="select * from TBL_CARPARTS where quantity<?"; //we just have to change the query
		List<CarPart> list=jt.query(sql, new CarPartRowMapper(),95);  //and give the values here
		return list;
	}
}
