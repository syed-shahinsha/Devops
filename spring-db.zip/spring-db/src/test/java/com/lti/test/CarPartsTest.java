package com.lti.test;

import java.util.List;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.component.CarPart;
import com.lti.component.CarPartsInventory;

public class CarPartsTest {
		@Test
		public void add() {
			ApplicationContext context = new ClassPathXmlApplicationContext("spring-config.xml");
			
			CarPartsInventory cp = (CarPartsInventory) context.getBean("carPartsImpl1");

			CarPart c= new CarPart();
			c.setPartNo(115);
			c.setCarModel("Agera RS");
			c.setQuantity(91);
			c.setPartName("Rim");
			
			int res=cp.addNewPart(c);
			if(res==1) {
				System.out.println("Inserted");
			}
		}
		@Test
		public void getAvailableParts() {
			ApplicationContext context = new ClassPathXmlApplicationContext("spring-config.xml");
			
			CarPartsInventory cp = (CarPartsInventory) context.getBean("carPartsImpl4");
			List<CarPart> list=cp.getAvailableParts();
			for(CarPart p:list) {
				System.out.println("Part No:" +p.getPartNo());
				System.out.println("Part name :"+p.getPartName());
				System.out.println("Car Model :"+p.getCarModel());
				System.out.println("----------------------");
			}
		}
	
}
