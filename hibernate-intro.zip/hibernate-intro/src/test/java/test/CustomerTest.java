package test;

import org.junit.Test;

import dao.CustomerDao;
import model.Customer;

public class CustomerTest {

	@Test
	public void testAdd() {
		Customer c = new Customer();
		c.setName("Syeddddd");
		c.setEmail("syedshaaaaaa9.i@gmail.com");
		c.setCity("Bangalore");
		// c.setDob(java.sql.Date.valueOf("1997-09-25"));
		CustomerDao dao = new CustomerDao();
		dao.fetch(25);
	}

	@Test
	public void testFetch() {
		Customer c = new Customer();
		CustomerDao dao = new CustomerDao();
		Customer cu=dao.fetch(25);
		System.out.println(cu.getName());
		System.out.println(cu.getCity());
		System.out.println(cu.getEmail());
		System.out.println(cu.getDob());
	
	}
	@Test
	public void testUpdate() {
		
		CustomerDao dao = new CustomerDao();
		Customer c = dao.fetch(25);
		c.setEmail("ssddd.i@gmail.com");
		c.setCity("Gujarat");
		
		dao.update(c);
	}

	@Test
	public void testDelete() {
		
		CustomerDao dao = new CustomerDao();
		Customer c = dao.fetch(25);
		
		dao.delete(c);
	}

}
