package dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import model.Customer;

public class CustomerDao {

	public void addInDatabase(Customer customer) {
		//Step 1.Load /create EntityManagerFactory object
		//In this step, META-INF/persistence.xml is read
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("oracleTest");
		
		//Step 2.Load/create EntityManager object
		EntityManager em=emf.createEntityManager();
		
		//Step 3.Start/Participate in a transaction
		EntityTransaction et=em.getTransaction();
		et.begin();
		
		//Now we can insert/update/delete/select as we want
		em.persist(customer); //persist method generates insert query
		et.commit();
		
		//below code should be in finally block
		em.close();
		emf.close();
		
	}
	public Customer fetch(int id) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("oracleTest");
		EntityManager em=emf.createEntityManager();
		Customer c=em.find(Customer.class, id); // find method generates select query
		em.close();
		emf.close();
		return c;
	}
	public void update(Customer cust) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("oracleTest");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		
		em.merge(cust);
		et.commit();
		
		em.close();
		emf.close();
		
	}
	public void delete(Customer cust) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("oracleTest");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		
		em.remove(cust);
		et.commit();
		
		em.close();
		emf.close();
		
	}
}
