package com.lti.training.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.lti.dto.StatusDTO;
import com.lti.dto.UserDTO;
import com.lti.service.RegisterService;

@RestController
public class RegisterController {

	@Autowired
	RegisterService service;

	@RequestMapping(path = "/register", method = RequestMethod.POST)
	public StatusDTO register(@RequestBody UserDTO user) {
		StatusDTO status = service.addUser(user);
		return status;
	}

	@RequestMapping(path = "/search", method=RequestMethod.GET)
	public UserDTO search(@RequestParam("id") int id) {
		UserDTO user = service.fetch(id);
		return user;
	}
}
