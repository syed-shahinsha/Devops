package com.lti.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dao.RegisterDao;
import com.lti.dto.StatusDTO;
import com.lti.dto.UserDTO;
import com.lti.entity.User;

@Service
public class RegisterService {

	@Autowired
	private RegisterDao dao;

	@Transactional
	public StatusDTO addUser(UserDTO user) {
		User u = new User();
		u.setName(user.getName());
		u.setAge(user.getAge());
		u.setEmail(user.getEmail());
		int id = dao.save(u);

		StatusDTO dto = new StatusDTO();
		dto.setId(id);
		dto.setMessage("Registered broo!!");
		return dto;
	}

	public UserDTO fetch(int id) {
		User u=dao.fetchByUserId(id);
		UserDTO user=new UserDTO();
		user.setName(u.getName());
		user.setAge(u.getAge());
		user.setEmail(u.getEmail());
		return user;
	}
}
