package com.lti.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.lti.entity.User;

@Repository
public class RegisterDao {

	@PersistenceContext
	public EntityManager em;

	
	public int save(User user) {
		User u=em.merge(user);
		return u.getId();
	}
	
	public User fetchByUserId(int id) {
		return em.find(User.class, id);
	}
	
}
